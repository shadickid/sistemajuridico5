<?php
$host = 'localhost';
$user = 'root';
$pass = '161101';
$db = 'ejercicio';

$connect = new mysqli($host, $user, $pass, $db);
if ($connect->connect_error) {
    die("Problemas con la conexion a la base de datos");
}
?>