<?php
require_once($_SERVER['DOCUMENT_ROOT'] . '/PROGRAMACION/config/path.php');
require_once(ROOT_PATH . 'config\database\connect.php');


function consultarPais(){
    global $connect;
    $connect->begin_transaction();
    $sql = 'SELECT * FROM ejercicio.pais;';
    $s = $connect->prepare($sql);

    $s->execute();

    $records = $s->get_result()->fetch_all(MYSQLI_ASSOC);

    $s->close();
    return $records;
}

function consultarProvincia($idPais){
    global $connect;
    $connect->begin_transaction();
    $sql="SELECT * FROM ejercicio.provincia where id_pais=$idPais;";
    $s = $connect->prepare($sql);

    $s->execute();

    $records = $s->get_result()->fetch_all(MYSQLI_ASSOC);

    $s->close();
    return $records;
}