<?php 
require_once($_SERVER['DOCUMENT_ROOT'] . '/PROGRAMACION/config/path.php');
require_once(ROOT_PATH . 'config\database\functions\db_functions.php');

$pais = consultarPais();
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <div>
        <form action="">
            <h1>Ejercicio</h1>
            <fieldset>
                <label for="">Pais:</label>
                <select name="pais" id="pais" onchange="cargarProvincias(this.value)">
                    <option value="0">seleccione</option>
                    <?php foreach ($pais as $regpais): ?>
                        <option value="<?php echo $regpais['id_pais'] ?>">
                            <?php echo $regpais['descripcion'] ?>
                        </option>

                    <?php endforeach; ?>
                </select>
            </fieldset>
        </form>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function () {


        })


        function cargarProvincias(idPais) {
            if (idPais !=0){
                $.post(
                    "provincia.php", _//archivo  del php de la url
                    {id_pais:idPais}, // paramtro que le paso (nombre de variable:variable) nombre de que lo amos a usar y el otro del jquery
                    function(data){
                        provincias=JSON.parse(data);// funcion de respuesta que me va dar el servidor
                       // alert(provincias[0]['descripcion']);
                        for(let i =0; provincias.length;i++){
                            let option =document.createElement('option');
                            option.apped(provincias[i]['descripcion'])
                            $('#provincias').append(option);
                            //alert(provincias[i]['descripcion']);
                        }
                    }
                )
            }else{
                alert("selecicone un pais")
            }

        }
    </script>
</body>

</html>