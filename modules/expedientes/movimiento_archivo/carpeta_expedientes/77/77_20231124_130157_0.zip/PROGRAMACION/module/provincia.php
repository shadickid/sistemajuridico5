<?php 
require_once($_SERVER['DOCUMENT_ROOT'] . '/PROGRAMACION/config/path.php');
require_once(ROOT_PATH . 'config\database\functions\db_functions.php');


$provincia=consultarProvincia($_POST['id_pais']); //aca recibe el de nombre de la varaible

echo json_encode($provincia);