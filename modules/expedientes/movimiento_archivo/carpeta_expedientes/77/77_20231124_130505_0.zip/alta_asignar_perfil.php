<?php
/* require_once('../../../config/path.php'); */
require_once($_SERVER['DOCUMENT_ROOT'] . '/SisEdu/config/path.php');
include(ROOT_PATH . 'config/database/functions/perfilesxmodulos.php');
include(ROOT_PATH . 'includes\header.php');
include(ROOT_PATH . 'includes\nav.php');
$id_modulos = $_GET['id_modulos'];
$modulo_nombre = $_GET['modulo_nombre'];
?>
<div class="titulo">
    <h1>Asignar Nuevo Perfil - <?php echo $modulo_nombre ?></h1>
</div>
<div class="mapa">    
    <div class="contenedor-icono-navegacion">
        <a href="<?php echo BASE_URL?>modules/modulos/listado_asignar_perfil.php?id_modulos=<?php echo $id_modulos ?>&modulo_nombre=<?php echo $modulo_nombre ?>"><button class="volver-boton"><img src="<?php echo BASE_URL?>/img/volver.png" class="volver-icono">Volver</button></a>
    </div>
    <a href="<?php echo BASE_URL?>modules/interfaz/formulario.php">Inicio</a>
    <span>/</span>
    <a href="<?php echo BASE_URL?>modules/Modulos/listado_Modulos.php">Modulos</a>
    <span>/</span>
    <a href="<?php echo BASE_URL?>modules/Modulos/listado_Modulos.php">Gestionar Modulos</a>
    <span>/</span>
    <a href="<?php echo BASE_URL?>modules/modulos/listado_asignar_perfil.php?id_modulos=<?php echo $id_modulos ?>&modulo_nombre=<?php echo $modulo_nombre ?>">Listado de Perfiles</a>
    <span>/</span>
    <a>Asignar Modulos</a>
</div>
<?php if(isset($_GET['error'])) {?>
    <?php if ($_GET['error'] == '1'){ ?>
        <span class='mensaje-error'>Error: Perfil ya asignado</span>
    <?php }}?>
<div class="contenedor">
    <section class="contenedor-contenido">
        <form action="procesar_alta_asignar_perfil.php" method="POST">
            <label>M&oacute;dulo:</label>
            <input type="text" name="modulo_nombre_lista" value="<?php echo $modulo_nombre ?>" readonly disabled>
            <label>Perfiles:</label>
                <select class="select-multiple" name="perfil_valor[]" multiple="multiple" style="width: 100%">
                    <?php
                    $query = "SELECT * from sisedu_proyecto.perfiles where activo = '1';";
                    $result = $conexion->query($query);
                    while ($regs = $result->fetch_assoc()){
                    ?>
                        <option value="<?php echo $regs['id_perfiles'];?>">
                            <?php echo $regs['descripcion']; ?>
                        </option>
                    <?php } ?>
                </select>
            <input type="hidden" name="id_modulos" value="<?php echo $id_modulos ?>">
            <input type="hidden" name="modulo_nombre" value="<?php echo $modulo_nombre ?>">
            <input type="submit" value="Guardar">
        </form>
    </section>
</div>
<?php
include(ROOT_PATH . 'includes\footer.php');
?>