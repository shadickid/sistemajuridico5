<?php
/* require_once('../../../config/path.php'); */
require_once($_SERVER['DOCUMENT_ROOT'] . '/SisEdu/config/path.php');
include(ROOT_PATH . 'config/database/functions/Modulos.php');
include(ROOT_PATH . 'includes\header.php');
include(ROOT_PATH . 'includes\nav.php');
?>
<div class="titulo">
    <h1>Alta de Nuevo M&oacute;dulo</h1>
</div>
<div class="mapa">    
    <div class="contenedor-icono-navegacion">
        <a href="<?php echo BASE_URL?>modules/profesionales/alta_personas_volver.php?persona_cargada=<?php echo $id_persona_cargada ?>&domicilio_cargado=<?php echo $id_domicilio_cargado ?>"><button class="volver-boton"><img src="<?php echo BASE_URL?>/img/volver.png" class="volver-icono">Volver</button></a>
    </div>
    <a href="<?php echo BASE_URL?>modules/interfaz/formulario.php">Inicio</a>
    <span>/</span>
    <a href="<?php echo BASE_URL?>modules/Modulos/listado_Modulos.php">Modulos</a>
    <span>/</span>
    <a href="<?php echo BASE_URL?>modules/Modulos/listado_Modulos.php">Gestionar Modulos</a>
    <span>/</span>
    <a>Alta M&oacute;dulo</a>
</div>
<?php if(isset($_GET['error'])) {?>
    <?php if ($_GET['error'] == '1'){ ?>
        <span class='mensaje-error'>Error: Modulo ya registrado</span>
<?php }}?>
<div class="contenedor">
    <section class="contenedor-contenido">
        <form action="procesar_alta_modulos.php" method="POST">
            <label>Nombre:</label>
            <input type="text" name="descripcion" autocomplete="off" required>
            <label>Ruta:</label>
            <input type="text" name="ruta" value="modules/interfaz/formulario.php" autocomplete="off" required>
            <label>Nivel (N&uacute;mero):</label>
            <input type="number" value="1" name="nivel" autocomplete="off" required>
            <label>Orden (N&uacute;mero):</label>
            <input type="number" value="1" name="orden" autocomplete="off" required>
            <label>Padre:</label>
                <select name="padre">
                    <option value="0">Sin Padre</option>
                    <?php
                    $query = "SELECT * from sisedu_proyecto.modulos;";
                    $result = $conexion->query($query);
                    while ($regs = $result->fetch_assoc()){
                    ?>
                        <option value="<?php echo $regs['id_modulos'];?>">
                            <?php echo $regs['descripcion']; ?>
                        </option>
                    <?php } ?>
                </select>
            <input type="submit" value="Guardar">
        </form>
    </section>
</div>
<?php
include(ROOT_PATH . 'includes\footer.php');
?>