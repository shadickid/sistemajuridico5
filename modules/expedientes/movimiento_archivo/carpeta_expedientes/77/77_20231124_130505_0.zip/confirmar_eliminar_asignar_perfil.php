<?php
require_once($_SERVER['DOCUMENT_ROOT'] . '/SisEdu/config/path.php');
include(ROOT_PATH . 'config/database/functions/perfilesxmodulos.php');
include(ROOT_PATH . 'config/database/functions/personas.php');
include(ROOT_PATH . 'config/database/functions/modulos.php');
include(ROOT_PATH . 'includes\header.php');
include(ROOT_PATH . 'includes\nav.php');
$id_modulos = $_GET['id_modulos'];
$modulo_nombre = $_GET['modulo_nombre'];
$id_perfiles_modulos = $_GET['id_perfiles_modulos'];
$perfil = $_GET['perfil'];
$records = Listado_Asignar_Modulos($id_modulos);
foreach ($records as $reg) :

?>
<div class="modal-baja">
    <section class="modal__body">
        <div class="titulo">
            <h1>Confirmar baja</h1>
        </div>
        <p>¿Est&aacute;s seguro que quieres eliminar el perfil <b><?php echo $perfil ?></b> del m&oacute;dulo <b><?php echo $modulo_nombre ?></b>?</p>
        <div class="icono-modal-baja">
            <a href="<?php echo BASE_URL?>modules/modulos/listado_asignar_perfil.php?id_modulos=<?php echo $id_modulos ?>&modulo_nombre=<?php echo $modulo_nombre ?>"><button class="cancelar-boton"><img src="<?php echo BASE_URL?>/img/volver.png" class="volver-icono">Cancelar</button></a>
            <a href="<?php echo BASE_URL?>modules/modulos/eliminar_asignar_perfil.php?id_perfiles_modulos=<?php echo $id_perfiles_modulos ?>&id_modulos=<?php echo $id_modulos ?>&modulo_nombre=<?php echo $modulo_nombre ?>"><button class="baja-boton"><img src="<?php echo BASE_URL?>/img/borrar.png" class="baja-icono">Confirmar</button></a>
        </div>
    </section>
</div>
<?php
endforeach;
include(ROOT_PATH . 'includes\footer.php');
?>