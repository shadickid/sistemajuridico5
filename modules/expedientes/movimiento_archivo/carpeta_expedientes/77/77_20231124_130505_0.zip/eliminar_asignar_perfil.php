<?php
require_once($_SERVER['DOCUMENT_ROOT'] . '/SisEdu/config/path.php');
include(ROOT_PATH . 'config/database/functions/perfilesxmodulos.php');
$id_modulos = $_GET['id_modulos'];
$modulo_nombre = $_GET['modulo_nombre'];
$id_perfiles_modulos = $_GET['id_perfiles_modulos'];

borrarPerfilxModulos($id_perfiles_modulos);
header("location: listado_asignar_perfil.php?id_modulos=$id_modulos&modulo_nombre=$modulo_nombre");