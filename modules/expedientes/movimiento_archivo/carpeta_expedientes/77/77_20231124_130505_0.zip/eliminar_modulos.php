<?php
require_once($_SERVER['DOCUMENT_ROOT'] . '/SisEdu/config/path.php');
include(ROOT_PATH . 'config/database/functions/modulos.php');
$id_modulos = $_GET['id_modulos'];

borrarModulos($id_modulos);
header("location: listado_modulos.php");