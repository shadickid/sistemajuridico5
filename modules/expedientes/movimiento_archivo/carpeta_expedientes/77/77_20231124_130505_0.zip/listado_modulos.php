<?php
/* require_once('../../../config/path.php'); */
require_once($_SERVER['DOCUMENT_ROOT'] . '/SisEdu/config/path.php');
include(ROOT_PATH . 'config/database/functions/general.php');
include(ROOT_PATH . 'includes\header.php');
include(ROOT_PATH . 'includes\nav.php');
include(ROOT_PATH . 'config/database/functions/Modulos.php');

$modulo_actual = "Gestionar Modulos";
$tiene_permiso = validarPermisoModulos($modulo_actual);


/* foreach ($listadoModulos as $key => $value) {
    if ($value == $modulo_actual) {
        $tiene_permiso = true;
        break;
    } */
if (!$tiene_permiso){
    echo "No tiene permiso";
    exit;
}

/*} 
    
                return true;
        }
    }
    return false;


$tiene_permiso = validarPermisoModulos($modulo_actual);

if (!$tiene_permiso) {
    echo "No tenes permiso";
    exit;
} */

$records = Listado_Modulos();
?>
<div class="titulo">
    <h1>Listado de Modulos</h1>
</div>
<div class="mapa">    
    <div class="contenedor-icono-navegacion">
        <a href="<?php echo BASE_URL?>modules/interfaz/formulario.php"><button class="volver-boton"><img src="<?php echo BASE_URL?>/img/volver.png" class="volver-icono">Volver</button></a>
    </div>
    <a href="<?php echo BASE_URL?>modules/interfaz/formulario.php">Inicio</a>
    <span>/</span>
    <a>Modulos</a>
    <span>/</span>
    <a>Gestionar Modulos</a>
</div>
<?php if(isset($_GET['exito'])) {?>
    <?php if ($_GET['exito'] == '1'){ ?>
        <span class='mensaje-correcto'>M&oacute;dulo registrado correctamente</span>
    <?php }elseif ($_GET['exito'] == '2'){?>
        <span class='mensaje-correcto'>Datos cambiados correctamente</span>
<?php }}?>
<div class="contenedor-lista">
    <div class="contenedor-icono-navegacion">
        <a href="alta_modulos.php"><button class="nuevo-boton"><img src="<?php echo BASE_URL?>/img/mas.png" class="nuevo-icono">Nuevo Modulo</button></a>
    </div>
    <section class="inicio">
        <table>
            <?php 
            if (!$records){
            ?>
                <p><?php echo "No se encontraron registros"; ?></p>
            <?php 
            } else {
            ?>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Ruta</th>
                <th>Nivel</th>
                <th>Orden</th>
                <th>Padre</th>
                <th>Perfiles</th>
                <th>Modificar</th>
                <th>Eliminar</th>
            </tr>
            <?php foreach ($records as $reg) : ?>
                <tr>
                    <td><?php echo $reg['id_modulos'] ?></td>
                    <td><?php echo $reg['descripcion'] ?></td>
                    <td><?php echo $reg['ruta'] ?></td>
                    <td><?php echo $reg['nivel'] ?></td>
                    <td><?php echo $reg['orden'] ?></td>
                    <td><?php echo $reg['padre'] ?></td>
                    <td>
                        <div class="contenedor-icono">
                            <a href="<?php echo BASE_URL?>modules/modulos/listado_asignar_perfil.php?id_modulos=<?php echo $reg['id_modulos'] ?>&modulo_nombre=<?php echo $reg['descripcion'] ?>"><button class="asignar-boton"><img src="<?php echo BASE_URL?>/img/asignar.png" class="asignar-icono">Asignar</button></a>
                        </div>
                    </td>
                    <td>
                        <div class="contenedor-icono">
                            <a href="modificar_modulos.php?id_modulos=<?php echo $reg['id_modulos'] ?>&modulo_nombre=<?php echo $reg['descripcion'] ?>&padre=<?php echo $reg['padre'] ?>"><button class="editar-boton"><img src="<?php echo BASE_URL?>/img/editar.png" class="editar-icono">Editar</button></a>
                        </div>
                    </td>
                    <td>
                        <div class="contenedor-icono">
                            <a href="confirmar_eliminar_modulos.php?id_modulos=<?php echo $reg['id_modulos'] ?>&modulo_nombre=<?php echo $reg['descripcion'] ?>"><button class="borrar-boton"><img src="<?php echo BASE_URL?>/img/borrar.png" class="borrar-icono">Borrar</button></a>
                        </div>
                    </td>
                </tr>
            <?php endforeach ?>
            <?php } ?>
        </table>
    </section>
</div>
<?php
include(ROOT_PATH . 'includes\footer.php');
?>