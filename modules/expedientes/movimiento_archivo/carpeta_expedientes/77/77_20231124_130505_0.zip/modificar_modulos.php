<?php
require_once($_SERVER['DOCUMENT_ROOT'] . '/SisEdu/config/path.php');
include(ROOT_PATH . 'config/database/functions/modulos.php');
include(ROOT_PATH . 'config/database/functions/general.php');
include(ROOT_PATH . 'includes\header.php');
include(ROOT_PATH . 'includes\nav.php');
$id_modulos = $_GET['id_modulos'];
$modulo_nombre = $_GET['modulo_nombre'];
$padre = $_GET['padre'];

$records = Listado_Modificarmodulos($id_modulos);
foreach ($records as $reg) :

?>
<div class="titulo">
    <h1>Editar Perfil</h1>
</div>
<div class="mapa">    
    <div class="contenedor-icono-navegacion">
        <a href="<?php echo BASE_URL?>modules/modulos/listado_modulos.php"><button class="volver-boton"><img src="<?php echo BASE_URL?>/img/volver.png" class="volver-icono">Volver</button></a>
    </div>
    <a href="<?php echo BASE_URL?>modules/interfaz/formulario.php">Inicio</a>
    <span>/</span>
    <a href="<?php echo BASE_URL?>modules/Modulos/listado_Modulos.php">Modulos</a>
    <span>/</span>
    <a href="<?php echo BASE_URL?>modules/Modulos/listado_Modulos.php">Gestionar Modulos</a>
    <span>/</span>
    <a>Modificar M&oacute;dulo</a>
</div>
<?php if(isset($_GET['error'])) {?>
    <?php if ($_GET['error'] == '1'){ ?>
        <span class='mensaje-error'>Error: No se puede asignar como padre</span>
    <?php }?>
<?php }?>
<div class="contenedor">
    <section class="contenedor-contenido">
        <form method="POST" action="procesar_modificacion_modulos.php">
            <label>Nombre:</label>
            <input type="text"  autocomplete="off" name="descripcion" value="<?php echo $reg['descripcion'] ?>" required>
            <label>Nivel:</label>
            <input type="number" name="nivel" value="<?php echo $reg['nivel'] ?>">
            <label>Orden:</label>
            <input type="number" name="orden" value="<?php echo $reg['orden'] ?>">
            <label>Padre:</label>
                <select name="padre">
                    <option value="0">Sin Padre</option>
                    <?php
                        $query = "SELECT * from sisedu_proyecto.modulos order by id_Modulos asc";
                        $result = $conexion->query($query);

                        if(mysqli_num_rows($result) > 0){
                            while($regs = mysqli_fetch_assoc($result)){
                                $selected = "";
                                if ($regs['padre'] == $padre) {
                                    $selected = " selected";
                                }
                                echo '<option value="' . htmlspecialchars($regs['id_modulos']) . '"' . $selected . '>' 
                                . htmlspecialchars($regs['descripcion']) 
                                . '</option>';
                            }
                        }                                             
                    ?> 
                </select>
            <input type="hidden" name="id_modulos" value="<?php echo $reg['id_modulos'] ?>">
            <input type="submit" value="Guardar">
        </form>
    </section>
</div>
<?php
endforeach;
include(ROOT_PATH . 'includes\footer.php');
?>