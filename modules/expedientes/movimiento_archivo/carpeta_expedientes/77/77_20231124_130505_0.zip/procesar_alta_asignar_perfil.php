<?php
require_once($_SERVER['DOCUMENT_ROOT'] . '/SisEdu/config/path.php');
/* include(ROOT_PATH . 'config\database\functions\personas.php'); */
include(ROOT_PATH . 'config/database/functions/perfilesxmodulos.php');
$id_modulos = $_POST['id_modulos'];
$modulo_nombre = $_POST['modulo_nombre'];
$perfil_cargado = $_POST['perfil_valor'];

foreach($perfil_cargado as $perfil_valor){
    
    $perfilesxmodulos_validar = "SELECT id_perfiles_modulos, id_perfiles from perfilesxmodulos  
        where id_modulos = '$id_modulos' and id_perfiles = '$perfil_valor' and perfilesxmodulos.activo = '1'";

    $verificar_dato_perfilesxmodulos = $conexion->query($perfilesxmodulos_validar);


    if($verificar_dato_perfilesxmodulos->num_rows > 0){
        header("location: alta_asignar_perfil.php?id_modulos=$id_modulos&modulo_nombre=$modulo_nombre&error=1");
    }else{
        agregarAsignarPerfil($perfil_valor, $id_modulos);
        header("location: listado_asignar_perfil.php?id_modulos=$id_modulos&modulo_nombre=$modulo_nombre&exito=1");
        
    }
}

