<?php
require_once($_SERVER['DOCUMENT_ROOT'] . '/SisEdu/config/path.php');
/* include(ROOT_PATH . 'config\database\functions\personas.php'); */
include(ROOT_PATH . 'config/database/functions/modulos.php');
$nivel = $_POST['nivel'];
$orden = $_POST['orden'];
$padre = $_POST['padre'];
$ruta = $_POST['ruta'];
$descripcion = $_POST['descripcion'];

$modulos_validar = "SELECT id_modulos, nivel, orden, padre, ruta, descripcion from modulos   
        where descripcion = '$descripcion' and activo = '1'";

$verificar_dato_modulos = $conexion->query($modulos_validar);


if($verificar_dato_modulos->num_rows > 0){
    header("location: alta_modulos.php?error=1");
}else{
    agregarModulos($nivel, $orden, $padre, $ruta, $descripcion);
    header("location: listado_modulos.php?exito=1");
    }
