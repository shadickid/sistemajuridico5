<?php
require_once($_SERVER['DOCUMENT_ROOT'] . '/SisEdu/config/path.php');
include(ROOT_PATH . 'config/database/functions/perfilesxmodulos.php');


$id_modulos = $_POST['id_modulos'];
$modulo_nombre = $_POST['modulo_nombre'];
$id_perfiles = $_POST['id_perfiles'];
$perfil = $_POST['perfil'];
$id_perfiles_modulos = $_POST['id_perfiles_modulos'];



$perfilesxmodulos_validar = "SELECT id_perfiles_modulos, id_perfiles from perfilesxmodulos 
    where id_modulos = '$id_modulos' and id_perfiles = '$id_perfiles' 
    and perfilesxmodulos.activo = '1'";

$verificar_dato_perfilesxmodulos = $conexion->query($perfilesxmodulos_validar);


if($verificar_dato_perfilesxmodulos->num_rows > 0){
    header("location: modificar_asignar_perfil.php?id_perfiles_modulos=$id_perfiles_modulos&id_modulos=$id_modulos&perfil=$perfil&modulo_nombre=$modulo_nombre&error=1");
}else{
    modificarPerfilAsignado($id_perfiles_modulos, $id_perfiles);
    header("location: listado_asignar_perfil.php?id_modulos=$id_modulos&modulo_nombre=$modulo_nombre&exito=2");
    
}
