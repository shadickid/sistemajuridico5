<?php
require_once($_SERVER['DOCUMENT_ROOT'] . '/SisEdu/config/path.php');
include(ROOT_PATH . 'config/database/functions/modulos.php');


$descripcion = $_POST['descripcion'];
$orden = $_POST['orden'];
$nivel = $_POST['nivel'];
$padre = $_POST['padre'];
$id_modulos = $_POST['id_modulos'];


$modulos_validar = "SELECT id_modulos, nivel, orden, padre, ruta, descripcion from modulos   
        where padre = '$padre' and id_modulos = '$id_modulos' and activo = '1'";

$verificar_dato_modulos = $conexion->query($modulos_validar);


if($verificar_dato_modulos->num_rows > 0){
    header("location: modificar_modulos.php?id_modulos=$id_modulos&modulo_nombre=$descripcion&padre=$padre&error=1");
}else{ 
    modificarModulos($nivel, $orden, $padre, $descripcion, $id_modulos);
    header("location: listado_modulos.php?exito=2");
}
    
